package com.hvh.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class PreHitScreen extends Screen {
    private ButtonWidget toggle;

    public PreHitScreen() {
        super(Text.literal("Options"));
    }

    @Override
    protected void init() {
        toggle = ButtonWidget.builder(label(), b -> {
            HvhClient.preHit = !HvhClient.preHit;
            b.setMessage(label());
        }).dimensions(width / 2 - 100, height / 2 - 10, 200, 20).build();
        addDrawableChild(toggle);
    }

    private Text label() {
        return Text.literal("PreHit: " + (HvhClient.preHit ? "ON" : "OFF"));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_K) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 40, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }
}
